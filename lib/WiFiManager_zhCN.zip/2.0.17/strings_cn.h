/**
 * Contents of this file have moved to 2 new locations
 * wm_strings_nn.h
 *  wm_consts_nn.h
 * @author winlam
 */

#warning "This file is deprecated"

#ifndef _STRINGS_CN_H_
#define _STRINGS_CN_H_

// strings files must include a consts file!
#include "wm_strings_cn.h" // include constants, tokens, routes

#endif